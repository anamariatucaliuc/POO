var MongoClient = require('mongodb').MongoClient;
var uri = "mongodb+srv://ana-maria2019:test@cluster0-4e4io.mongodb.net/RDF2RDF?retryWrites=true";
var client = new MongoClient(uri, {useNewUrlParser:true });
var db;

/*
    utilisateurs :
        nomUser
        prenomUser
        emailUser
        pseudoUser
        mdpUser

    listevocabulaire :
        nomList
        idcreateurList
        dateList
        idviewerList

    vocabulaire :
        nomTask
        idcreateurTask
        idListTask
        dateTask
        doneTask
*/


var datalayer = {
    init : function(cb){
        //Initialize connection once
        client.connect(function(err) {
            if(err) throw err;
            db = client.db("RDF2RDF");
            cb();
        });
    },
    get : function(collection, document, cb){
        if (document._id!=null){
            ObjectID = require('mongodb').ObjectID;
            document = {
                _id : new ObjectID(document._id)
            };
        }
        db.collection(collection).find(document).toArray(function(err, docs) {
            cb(docs);
        });
    },
    create : function(collection, document, cb){
        db.collection(collection).insertOne(document, function() {
            cb({success : true});
        });
    },
    update : function(collection, id, document, cb){
        ObjectID = require('mongodb').ObjectID;
        var ident = {
            _id : new ObjectID(id)
        };
        
    console.log(ident);
    console.log(document);
        db.collection(collection).updateOne(ident, {$set: document}, function(err, result) {
            cb({success : true});
        });        
    },
    delete : function(collection, id, cb){
        ObjectID = require('mongodb').ObjectID;
        var ident = {
            _id : new ObjectID(id)
        };
        console.log(ident);
        console.log(collection);
        db.collection(collection).deleteOne(ident, function(err, result) {
            cb({success : true});
        });        
    },
    
    deleteMany : function(collection, document, cb){        
        ObjectID = require('mongodb').ObjectID;
        if (document.idListTask!=null) document.idListTask = new ObjectID(document.idListTask)

        db.collection(collection).remove(document, function(err, result) {
            cb({success : true});
        });        
    }
};
module.exports=datalayer;
