var SkosApp = angular.module('SkosApp', []);

function IndexController($scope, $http){
  $scope.formData = {};
  $scope.idUser = GetCookie("idUser");
}